jQuery(document).ready(function($){
	/* SUBMIT SKRILL FORM */
	if( $('.skrill-payment').length > 0 ){
		$('.skrill-payment').submit();
	}
});